<?php

class ClientesGeneral_controller extends Controller {

    public function Agregar($origen) {
        $data = array();
        $id = null;
        $origen = $origen;
        $fecha = fecha_mysql;
        $hora = hora_mysql;
        $empresa = $_POST['empresa'];
        $correo_principal = $_POST['correo_principal'];
        $correo_secundario = $this->GenerarCorreo($correo_principal);
        $telefono = $_POST['telefono'];
        $id_ubigeo = empty($_POST['id_ubigeo']) ? '' : $_POST['id_ubigeo'];
        $mensaje = empty($_POST['mensaje']) ? '' : $_POST['mensaje'];
        $id_usuario_asignado = empty($_POST['id_usuario_asignado'] ? null : $_POST['id_usuario_asignado']);
        $id_empresa = Session::getValue('EMPRESA' . NOMBRE_SESSION);

        try {
            $cliente = new Clientes($id, mb_strtolower($origen), $fecha, $hora, mb_strtolower($empresa), mb_strtolower($correo_principal), mb_strtolower($correo_secundario), $telefono, $id_ubigeo, mb_strtolower($mensaje), $id_usuario_asignado, $id_empresa);
            $cliente->create();
            array_push($data, array(
                'respuesta' => 'ok',
                'respuesta_generar_correo' => $correo_secundario,
            ));
        } catch (Exception $ex) {
            array_push($data, array(
                'respuesta' => $e->getMessage(),
                'respuesta_generar_correo' => $correo_secundario,
            ));
        }
        echo json_encode($data, JSON_PRETTY_PRINT);

        //Correos_controller::EmailBienvenida($email, $empresa);*/
    }

    public function ContadorMostrar() {
        $data = array(
            'id_empresa' => Session::getValue('EMPRESA' . NOMBRE_SESSION),
        );
        $clientes = Clientes::whereVNull($data, 'and', 'id_usuario_asignado');
        $datos[] = "";
        $i = 0;
        foreach ($clientes as $value) {
            $i++;
        }
        array_push($datos, $datos['numero_clientes'] = $i);
        echo json_encode($datos, JSON_PRETTY_PRINT);
    }

    public function Mostrar() {
        $data = array(
            'id_empresa' => Session::getValue('EMPRESA' . NOMBRE_SESSION),
        );
        $clientes = Clientes::whereVNull($data, 'and', 'id_usuario_asignado');
        $datos = array();
        $i = 0;
        foreach ($clientes as $value) {
            $i++;
            $ubigeo = Ubigeo_controller::ubigeo_completo($value['id_ubigeo']);
            array_push($datos, array(
                'contador' => $i,
                'id' => $value['id'],
                'origen' => $value['origen'],
                'fecha' => $value['fecha'],
                'hora' => $value['hora'],
                'empresa' => $value['empresa'],
                'departamento' => $ubigeo['departamento'],
                'provincia' => $ubigeo['provincia'],
                'distrito' => $ubigeo['distrito'],
                'mensaje' => $value['mensaje'],
            ));
        }
        echo json_encode($datos, JSON_PRETTY_PRINT);
    }

    public function AceptarCliente($id) {
        $cliente = Clientes::getById($id);
        $cliente->setId_usuario_asignado(Session::getValue('ID' . NOMBRE_SESSION));
        $cliente->update();
    }

    public function GenerarCorreo($correo_principal) {
        $correo_principal = explode("@", $correo_principal);
        $correo = trim($correo_principal[0]);
        $correo = Hash::create(ALGORITMO_CORREO, $correo, HASHKEY);
        return Cpanel::Iniciar($correo, "kassandra@2015");
        
    }

}
