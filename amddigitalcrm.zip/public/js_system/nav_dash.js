$(function () {
    const app = new Vue({
        el: '#nav_dash_arriba',
        data: {
            numeroclientes: 0,
        },
        store: store,
        computed: {
            ...Vuex.mapState(['numero'])
        },
        created: function () {
            this.LlamarContadorClientes();
        },
        methods: {
            LlamarContadorClientes: function () {
                var url = URLPRINCIPAL + 'ClientesGeneral/ContadorMostrar';
                this.$http.get(url, {
                    before: function () {
                    },
                }).then(
                    response => {
                        this.numeroclientes = response.body.numero_clientes;
                    }, response => { });
            },
        }
    });
    try {
        document.getElementById('offcanvas').addEventListener('click', function (e) {
            $('#wrapper').toggleClass('toggled');
        });
        document.getElementById('cerrar_sesion').addEventListener('click', function (e) {
            location.href = URLPRINCIPAL + "Login/destroy_session";
        });
        var nav_clientes_general = document.getElementsByClassName("nav_clientes_general");
        for (var i = 0; i < nav_clientes_general.length; i++) {
            nav_clientes_general[i].addEventListener('click', function () {
                location.href = URLPRINCIPAL + "Cpanel/Pagina/clientes_general";
            });
        }
        document.getElementById('mis_clientes').addEventListener('click', function (e) {
            location.href = URLPRINCIPAL + "Cpanel/Pagina/mis_clientes";
        });
    } catch (error) {
        alert(error);
    }
});