$(function () {
    var table;
    const app = new Vue({
        el: '#app',
        data: {
            ubigeos: [],
            usuarios: [],
            select: null,
        },
        mounted: function () {
            this.LlamarUsuarios();
            this.LlamarUbigeo();
        },
        methods: {
            AgregarCliente: function (event) {
                event.preventDefault();
                var id_formulario = document.getElementById("form_agregar_cliente");
                var input_empresa = document.getElementById("input_empresa");
                var formData = new FormData(id_formulario);
                var url = URLPRINCIPAL + 'ClientesGeneral/Agregar/CRM';
                this.$http.post(url, formData).then(response => {
                    id_formulario.reset();
                    input_empresa.focus();                    
                    console.log(response);
                }, response => { });
            },
            LlamarUbigeo: function () {
                var url = URLPRINCIPAL + 'Ubigeo/MostrarUbigeos';
                this.$http.get(url, {
                    before: function () {
                    },
                }).then(
                    response => {
                        this.ubigeos = response.body;
                        this.select = $('.select_ubigeos').selectpicker();
                    }, response => { });
            },
            LlamarUsuarios: function () {
                var url = URLPRINCIPAL + 'Usuario/MostrarUsuarios';
                this.$http.get(url, {
                    before: function () {
                    },
                }).then(
                    response => {
                        this.usuarios = response.body;
                        this.select = $('.select_usuarios').selectpicker();
                    }, response => { });
            },
        },
    });

});

