<?php
//Parámetros GENERALES
define('URL', '/amddigitalcrm/'); 
define('URLHTDOCS', 'C:/xampp/htdocs/');
define('PREFIJO','t_');
//Parámetros DB
define('_DB_TYPE', 'mysql'); 
define('_DB_HOST', 'localhost'); 
define('_DB_USER', 'root');  
define('_DB_PASS', ''); 
define('_DB_NAME', 'amdigital'); 
//
define('NOMBRE_LOGO', 'logo.svg');
define('NOMBRE_LOGO_', 'logo_.svg');
define('NOMBRE_FAVICON', 'favicon.png');
define('NOMBRE_EMPRESA', 'amddigital');
//
define('AUTHOR', 'Marco Antonio Rodriguez Salinas');
define('DESCRIPTION', '');
define('KEYWORDS', '');
define('VERSION', '1.0');



